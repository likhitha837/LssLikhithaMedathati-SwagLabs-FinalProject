package SwagLabs;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class BasicTestClass_01 {
	private WebDriver driver;

	@BeforeClass
	public void setUp() throws InterruptedException {
		// Setting up ChromeDriver
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		Thread.sleep(2000);
		// Navigating to the inventory page
		driver.get("https://www.saucedemo.com/");
	}

	@Test(priority = 1)
	public void verifyHomePageURL() {
		// Verifying homepage URL
		String actualURL = driver.getCurrentUrl();
		String expectedURL = "https://www.saucedemo.com/";
		driver.findElement(By.id("user-name")).sendKeys("performance_glitch_user");
		driver.findElement(By.name("password")).sendKeys("secret_sauce");
		Assert.assertEquals(actualURL, expectedURL, "Mismatched URL");
		driver.findElement(By.id("login-button")).click();
	}

	@Test(priority = 2)
	public void verifyLogoAndSymbols() {
		// Verifying the presence of logo and symbols
		WebElement logo = driver.findElement(By.className("app_logo"));
		Assert.assertTrue(logo.isDisplayed(), "Logo is not displayed");

		WebElement cart = driver.findElement(By.xpath("//*[@id=\"shopping_cart_container\"]"));
		Assert.assertTrue(cart.isDisplayed(), "Shopping cart icon is not displayed");
	}

	@Test (priority = 3)
	public void verifyDropdownOptions() throws InterruptedException {
		WebElement dropdown = driver.findElement(By.xpath("//*[@id=\"header_container\"]/div[2]/div/span/select"));
		dropdown.click();
	}

	@Test(priority = 4)
	public void addProductToCart() {
		// Adding a product to the cart
		WebElement addToCartButton = driver.findElement(By.xpath("//*[@id=\"add-to-cart-sauce-labs-onesie\"]"));
		addToCartButton.click();
		// Verifying if the product is added to the cart
		WebElement cartCount = driver.findElement(By.id("shopping_cart_container"));
		Assert.assertTrue(cartCount.isDisplayed() && cartCount.getText().equals("1"), "Product is not added to the cart");
	}

	@Test(priority = 5)
	public void removeProductFromCart() {
		// Removing a product from the cart
		WebElement removeButton = driver.findElement(By.xpath("//*[@id=\"remove-sauce-labs-onesie\"]"));
		removeButton.click();
		// Verifying if the product is removed from the cart
		WebElement cartCount = driver.findElement(By.id("shopping_cart_container"));
		Assert.assertFalse(!cartCount.isDisplayed() || cartCount.getText().equals("0"), "Product is not removed from the cart");
	}

	@Test(priority = 6)
	public void filterProductsByName() throws InterruptedException {
		// Applying a filter to display products by name
		WebElement filterDropdown = driver.findElement(By.xpath("//*[@id=\"header_container\"]/div[2]/div/span/select"));
		filterDropdown.click();
		WebElement optionName = driver.findElement(By.xpath("//*[@id=\"header_container\"]/div[2]/div/span/select/option[1]"));
		optionName.click();
		// Verifying if the products are filtered correctly
		WebElement firstProduct = driver.findElement(By.xpath("//*[@id=\"item_4_title_link\"]/div"));
		String firstName = firstProduct.getText();
		//WebElement lastProduct = driver.findElement(By.xpath("(//*[@class='inventory_item'])[last()]"));

		WebElement lastProduct = driver.findElement(By.xpath("/html/body/div[1]/div/div/div[2]/div/div/div/div[6]/div[2]/div[1]/a/div[last()]"));
		Thread.sleep(4000);
		String lastName = lastProduct.getText();
		Assert.assertTrue(firstName.compareTo(lastName) <= 0, "Products are not filtered correctly");
	}

	@Test(priority = 7)
	public void filterProductsByPriceRange() {
		// Applying a filter to display products within a price range
		WebElement filterDropdown = driver.findElement(By.xpath("//*[@id=\"header_container\"]/div[2]/div/span/select"));
		filterDropdown.click();
		WebElement optionPrice = driver.findElement(By.xpath("//*[@id=\"inventory_container\"]/div/div[1]/div[2]/div[2]")); // Update the XPath to select the price range option

		optionPrice.click();
		// Verifying if the products are filtered correctly
		WebElement firstProductPrice = driver.findElement(By.xpath("//*[@id=\"inventory_container\"]/div/div[1]/div[2]/div[2]")); // Correct the XPath to select the price of the first product
		String firstPriceText = firstProductPrice.getText().split("\n")[0]; // Split the text to remove any non-numeric characters
		double firstPrice = Double.parseDouble(firstPriceText.replace("$", "").trim());
		Assert.assertFalse(firstPrice >= 1 && firstPrice <= 10, "First product price is not within the expected range");

		WebElement lastProductPrice = driver.findElement(By.xpath("//*[@id=\"inventory_container\"]/div/div[6]/div[2]/div[2]")); // Correct the XPath to select the price of the last product
		String lastPriceText = lastProductPrice.getText().split("\n")[0]; // Split the text to remove any non-numeric characters
		double lastPrice = Double.parseDouble(lastPriceText.replace("$", "").trim());
		Assert.assertTrue(lastPrice >= 11 && lastPrice <= 20, "Last product price is not within the expected range");
	}


	@Test(priority = 8)
	public void addToCartFromDetailsPage() {
		// Clicking on a product to view its details
		WebElement product = driver.findElement(By.className("inventory_item_img"));
		product.click();

		// Adding the product to the cart
		WebElement addToCartButton = driver.findElement(By.xpath("//*[@id=\"inventory_item_container\"]/div/div/div[1]"));
		addToCartButton.click();

		// Verifying that the product is added to the cart
		WebElement cartBadge = driver.findElement(By.id("shopping_cart_container"));
		Assert.assertTrue(cartBadge.isDisplayed(), "Product was not added to the cart");
	}

	@Test(priority = 9)
	public void verifyProductDetails() {

		// Verifying if all relevant product details are displayed
		String productName = driver.findElement(By.xpath("//*[@id=\"inventory_item_container\"]/div/div/div[2]/div[1]")).getText();
		System.out.println("This is the product name ->" + productName);
		//			Assert.assertTrue(productName.isDisplayed(), "Product name is not displayed");

		WebElement productDescription = driver.findElement(By.xpath("//*[@id=\"inventory_item_container\"]/div/div/div[2]/div[2]"));
		Assert.assertTrue(productDescription.isDisplayed(), "Product description is not displayed");

		WebElement productPrice = driver.findElement(By.className("inventory_details_price"));
		Assert.assertTrue(productPrice.isDisplayed(), "Product price is not displayed");

		WebElement addToCartButton = driver.findElement(By.xpath("//*[@id=\"inventory_item_container\"]/div/div/div[2]/div[3]"));
		Assert.assertTrue(addToCartButton.isDisplayed(), "Add to cart button is not displayed");
	}


	@AfterClass
	public void tearDown() {
		// Closing the browser
		if (driver != null) {
			driver.quit();
		}
	}
}
