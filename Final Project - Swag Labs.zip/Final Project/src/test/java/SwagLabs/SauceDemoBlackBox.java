package SwagLabs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Test
@Listeners(ListenersCommands.class)
public class SauceDemoBlackBox {

	WebDriver driver;

	public void expFailTest() throws InterruptedException {
		driver = new ChromeDriver();
		driver.get("https://www.saucedemo.com/");
		driver.manage().window().maximize();
		Thread.sleep(4000);

		// Verify initial URL
		String actualURL = driver.getCurrentUrl();
		String expectedURL = "https://www.saucedemo.com/";
		Assert.assertEquals(actualURL, expectedURL, "Link Mismatch");
		System.out.println("On correct SauceDemo site");

		// Perform login
		driver.findElement(By.id("user-name")).sendKeys("standard_user");
		driver.findElement(By.id("password")).sendKeys("secret_sauce");
		driver.findElement(By.id("login-button")).click();
		Thread.sleep(4000);

		// Verify navigation to the inventory page
		String actualInventoryUrl = driver.getCurrentUrl();
		String expectedInventoryUrl = "https://www.saucedemo.com/inventory.html";
		Assert.assertEquals(actualInventoryUrl, expectedInventoryUrl, "Link Mismatch for Inventory");
		System.out.println("Reached the inventory page");

		// Add product to the cart
		WebElement addToCartButton = driver.findElement(By.id("add-to-cart-sauce-labs-backpack"));
		addToCartButton.click();
		Thread.sleep(3000);
		System.out.println("Product added to cart");

		// Go to the cart
		WebElement cartIcon = driver.findElement(By.className("shopping_cart_link"));
		cartIcon.click();
		Thread.sleep(3000);

		// Verify cart contents
		WebElement cartItem = driver.findElement(By.className("cart_item"));
		Assert.assertNotNull(cartItem, "Cart is empty");
		System.out.println("Product is in the cart");

		// Proceed to checkout
		WebElement checkoutButton = driver.findElement(By.id("checkout"));
		checkoutButton.click();
		Thread.sleep(3000);

		// Fill in checkout information
		driver.findElement(By.id("first-name")).sendKeys("John");
		driver.findElement(By.id("last-name")).sendKeys("Doe");
		driver.findElement(By.id("postal-code")).sendKeys("12345");
		driver.findElement(By.id("continue")).click();
		Thread.sleep(3000);

		// Finish checkout
		WebElement finishButton = driver.findElement(By.id("finish"));
		finishButton.click();
		Thread.sleep(4000);

		// Verify order completion
		WebElement confirmation = driver.findElement(By.className("complete-header"));
		Assert.assertTrue(confirmation.getText().contains("Thank you for your order!"), "Order not completed");
		System.out.println("Order successfully completed");

		// Logout
		WebElement menuButton = driver.findElement(By.id("react-burger-menu-btn"));
		menuButton.click();
		Thread.sleep(2000);
		WebElement logoutLink = driver.findElement(By.id("logout_sidebar_link"));
		logoutLink.click();
		Thread.sleep(4000);

		// Verify logout
		String loginPageURL = driver.getCurrentUrl();
		Assert.assertTrue(loginPageURL.equals(expectedURL), "Did not navigate back to login page");

		// Close browser
		driver.quit();
	}
}
