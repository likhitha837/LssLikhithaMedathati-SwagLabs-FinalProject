package SwagLabs;

import java.io.File;
import java.io.IOException;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class ScreenShot {

	WebDriver driver;

	// Method to initialize WebDriver and navigate to SauceDemo URL
	@Test(priority = 1)
	public void navigateToSauceDemo() throws IOException {
		driver = new ChromeDriver();
		driver.get("https://www.saucedemo.com/");
		driver.manage().window().maximize();
		takeScreenshot("NavigateToSauceDemo");
	}

	// Method to log in to SauceDemo
	@Test(priority = 2)
	public void loginToSauceDemo() throws InterruptedException, IOException {
		driver.findElement(By.id("user-name")).sendKeys("standard_user");
		driver.findElement(By.id("password")).sendKeys("secret_sauce");
		driver.findElement(By.id("login-button")).click();
		Thread.sleep(4000);
		takeScreenshot("LoginToSauceDemo");

		// Verify navigation to inventory page
		String actualInventoryUrl = driver.getCurrentUrl();
		String expectedInventoryUrl = "https://www.saucedemo.com/inventory.html";
		Assert.assertEquals(actualInventoryUrl, expectedInventoryUrl, "URL mismatched for Inventory page");
	}

	// Method to perform actions on inventory page and take a screenshot
	@Test(priority = 3)
	public void inventoryActions() throws InterruptedException, IOException {
		// Add a product to the cart
		WebElement addToCartButton = driver.findElement(By.id("add-to-cart-sauce-labs-backpack"));
		addToCartButton.click();
		Thread.sleep(2000);
		takeScreenshot("ProductAddedToCart");

		// Verify product added to cart
		WebElement cartIcon = driver.findElement(By.className("shopping_cart_link"));
		cartIcon.click();
		Thread.sleep(2000);
		takeScreenshot("CartView");

		// Verify cart contents
		WebElement cartItem = driver.findElement(By.className("cart_item"));
		Assert.assertNotNull(cartItem, "Cart is empty");
		System.out.println("Product is in the cart");

		// Proceed to checkout
		WebElement checkoutButton = driver.findElement(By.id("checkout"));
		checkoutButton.click();
		Thread.sleep(2000);

		// Fill in checkout information
		driver.findElement(By.id("first-name")).sendKeys("John");
		driver.findElement(By.id("last-name")).sendKeys("Doe");
		driver.findElement(By.id("postal-code")).sendKeys("12345");
		driver.findElement(By.id("continue")).click();
		Thread.sleep(2000);

		// Finish checkout
		WebElement finishButton = driver.findElement(By.id("finish"));
		finishButton.click();
		Thread.sleep(4000);
		takeScreenshot("OrderCompleted");

		// Verify order completion
		WebElement confirmation = driver.findElement(By.className("complete-header"));
		Assert.assertTrue(confirmation.getText().contains("Thank you for your order!"), "Order not completed");
		System.out.println("Order successfully completed");
	}

	// Method to take a screenshot
	public void takeScreenshot(String screenshotName) throws IOException {
		Date currentdate = new Date();
		String screenshotfilename = currentdate.toString().replace(" ", "-").replace(":", "-");
		File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(screenshotFile, new File(".//screenshots//" + screenshotName + "-" + screenshotfilename + ".png"));
	}
}
