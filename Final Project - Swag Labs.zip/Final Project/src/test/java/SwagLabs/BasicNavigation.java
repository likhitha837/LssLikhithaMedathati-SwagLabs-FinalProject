package SwagLabs;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

public class BasicNavigation {
    protected WebDriver driver;

    @BeforeClass
    public void setUp() {
        // Initialize the WebDriver (ChromeDriver in this case)
        driver = new ChromeDriver();
    }

    @AfterClass
    public void tearDown() {
        // Quit the WebDriver session
        if (driver != null) {
            driver.quit();
        }
    }
}
