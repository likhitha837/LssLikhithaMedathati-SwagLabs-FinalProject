package SwagLabs;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class RandomListeners {
	WebDriver driver;

	// Login to SauceDemo
	@Test(priority=1)
	public void login() {
		// Initialize Chrome driver
		driver = new ChromeDriver();
		// Navigate to SauceDemo URL
		driver.get("https://www.saucedemo.com/");
		driver.manage().window().maximize();

		// Verify initial URL
		String actualURL = driver.getCurrentUrl();
		String expectedURL = "https://www.saucedemo.com/";
		Assert.assertEquals(actualURL, expectedURL, "URL mismatched");

		// Perform login
		driver.findElement(By.id("user-name")).sendKeys("standard_user");
		driver.findElement(By.id("password")).sendKeys("secret_sauce");
		driver.findElement(By.id("login-button")).click();

		// Wait for a while to ensure the login process completes
		try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		// Verify navigation to the inventory page
		String actualInventoryUrl = driver.getCurrentUrl();
		String expectedInventoryUrl = "https://www.saucedemo.com/inventory.html";
		Assert.assertEquals(actualInventoryUrl, expectedInventoryUrl, "URL mismatched for Inventory page");
	}

	// Perform actions in the inventory page
	@Test(priority=2)
	public void inventoryActions() throws InterruptedException {
		try {
			// Add a product to the cart
			WebElement addToCartButton = driver.findElement(By.id("add-to-cart-sauce-labs-backpack"));
			addToCartButton.click();
			Thread.sleep(2000);

			// Verify product added to cart
			WebElement cartIcon = driver.findElement(By.className("shopping_cart_link"));
			cartIcon.click();
			Thread.sleep(2000);

			// Verify cart contents
			WebElement cartItem = driver.findElement(By.className("cart_item"));
			Assert.assertNotNull(cartItem, "Cart is empty");
			System.out.println("Product is in the cart");

			// Proceed to checkout
			WebElement checkoutButton = driver.findElement(By.id("checkout"));
			checkoutButton.click();
			Thread.sleep(2000);

			// Fill in checkout information
			driver.findElement(By.id("first-name")).sendKeys("John");
			driver.findElement(By.id("last-name")).sendKeys("Doe");
			driver.findElement(By.id("postal-code")).sendKeys("12345");
			driver.findElement(By.id("continue")).click();
			Thread.sleep(2000);

			// Finish checkout
			WebElement finishButton = driver.findElement(By.id("finish"));
			finishButton.click();
			Thread.sleep(4000);

			// Verify order completion
			WebElement confirmation = driver.findElement(By.className("complete-header"));
			Assert.assertTrue(confirmation.getText().contains("Thank you for your order!"), "Order not completed");
			System.out.println("Order successfully completed");

		} catch (NoSuchElementException e) {
			e.printStackTrace();
		}

		// Logout
		WebElement menuButton = driver.findElement(By.id("react-burger-menu-btn"));
		menuButton.click();
		Thread.sleep(2000);
		WebElement logoutLink = driver.findElement(By.id("logout_sidebar_link"));
		logoutLink.click();
		Thread.sleep(4000);

		// Verify logout
		String loginPageURL = driver.getCurrentUrl();
		String expectedURL = "https://www.saucedemo.com/";
		Assert.assertEquals(loginPageURL, expectedURL, "Did not navigate back to login page");

		System.out.println("Login successful");
		Thread.sleep(5000);

		// Close browser
		driver.quit();
	}
}
