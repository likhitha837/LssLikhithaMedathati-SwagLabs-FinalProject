package SwagLabs;

import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Test
@Listeners(ListenersCommands.class)
public class SauceDemoListeners extends BasicNavigation {

    @Test(priority = 1)
    public void appLaunching() throws InterruptedException {
        // Launch the SauceDemo URL
        driver.get("https://www.saucedemo.com/");
        driver.manage().window().maximize();
        Thread.sleep(4000);
    }

    @Test(priority = 2)
    public void verifyTitle() {
        // Get the actual title
        String actualTitle = driver.getTitle();
        // Define the expected title
        String expectedTitle = "Swag Labs"; // The actual title of the SauceDemo page
        // Verify the title
        Assert.assertEquals(actualTitle, expectedTitle, "Page title does not match the expected title");
    }
}
