package SwagLabs;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class SearchDetails_02 {

	// Declare the WebDriver
	WebDriver driver;

	@Test(priority=1)
	public void testSauceDemo() throws InterruptedException {
		// Initialize SoftAssert to perform assertions without stopping the test immediately
		SoftAssert softassert = new SoftAssert();

		// Initialize Chrome driver
		driver = new ChromeDriver();

		// Navigate to SauceDemo URL
		driver.get("https://www.saucedemo.com/");
		driver.manage().window().maximize();

		// Verify URL
		String actualURL = driver.getCurrentUrl();
		String expectedURL = "https://www.saucedemo.com/";
		softassert.assertEquals(actualURL, expectedURL, "Mismatched URL");

		// Locate username field by ID and enter username
		driver.findElement(By.id("user-name")).sendKeys("performance_glitch_user");
		driver.findElement(By.name("password")).sendKeys("secret_sauce");
		driver.findElement(By.id("login-button")).click();
		Thread.sleep(2000);

		// Initialize WebDriverWait with a 20-second timeout
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		// Wait until the URL contains "/inventory.html" indicating the inventory page has loaded
		wait.until(ExpectedConditions.urlContains("https://www.saucedemo.com/inventory.html"));

		// Verify that the URL is the inventory page
		String inventoryURL = driver.getCurrentUrl();
		Assert.assertTrue(inventoryURL.contains("https://www.saucedemo.com/inventory.html"), "Did not navigate to inventory page");

		// Locate and get the text of the element with class name "title" (page title)
		String results = driver.getTitle();
		System.out.println("Text found: " + results);
		Thread.sleep(2000);

		// Locate a specific product by its XPath and get its text
		WebElement product = driver.findElement(By.xpath("//*[@id=\"item_4_title_link\"]/div"));
		System.out.println("Product Found: " + product.getText());
		// Click on the located product
		product.click();
		Thread.sleep(2000);

		// Locate and click the add-to-cart button for "Sauce Labs Backpack" by its ID
		WebElement addToCartButton = driver.findElement(By.id("add-to-cart"));
		addToCartButton.click();
		Thread.sleep(3000);
		System.out.println("Successfully added to cart");

		// Locate the cart icon by its class name and click it
		WebElement cartIcon = driver.findElement(By.className("shopping_cart_link"));
		cartIcon.click();
		Thread.sleep(2000);

		// Verify that the cart contains items by locating an element with the class name 
		WebElement cartItem = driver.findElement(By.className("shopping_cart_badge"));
		Assert.assertNotNull(cartItem, "Cart is empty");

		// Locate and click the checkout button by its ID
		WebElement checkoutButton = driver.findElement(By.id("checkout"));
		checkoutButton.click();
		Thread.sleep(2000);

		// Fill in checkout information fields by their IDs
		driver.findElement(By.id("first-name")).sendKeys("John");
		driver.findElement(By.id("last-name")).sendKeys("Doe");
		driver.findElement(By.id("postal-code")).sendKeys("12345");
		driver.findElement(By.id("continue")).click();
		Thread.sleep(2000);

		// Locate and click the finish button by its ID to complete the checkout
		WebElement finishButton = driver.findElement(By.id("finish"));
		finishButton.click();
		Thread.sleep(2000);

		// Verify that the order is completed by checking the text of an element with the class name 
		WebElement confirmation = driver.findElement(By.xpath("//*[@id=\"header_container\"]/div[2]/span"));
		Assert.assertFalse(confirmation.getText().contains("Thank you for your order!"), "Order not completed");

		System.out.println("Order successfully completed");

		// Locate and click the menu button by its ID
		WebElement menuButton = driver.findElement(By.className("bm-burger-button"));
		menuButton.click();
		Thread.sleep(2000);

		// Locate and click the logout link by its ID
		WebElement logoutLink = driver.findElement(By.id("logout_sidebar_link"));
		logoutLink.click();
		Thread.sleep(4000);

		// Verify that the URL after logout is the login page URL
		String loginPageURL = driver.getCurrentUrl();
		Assert.assertTrue(loginPageURL.equals(expectedURL), "Did not navigate back to login page");

		// Close the browser
		driver.quit();

		// Assert all soft assertions
		softassert.assertAll();
	}
}
